# final_python_project
Final python project for MIMUW course of python
